#!/bin/bash
apt install php php-sqlite3 php-gd
